Anpassen an den LaunchControl

Dissdegree Constraints komplettieren (10, 11)



/*
Überlegung "Welche Parameter für die Listen?"
1. Chromatik
2. Messiaen3 - 0,2,3,4,6,7,8,10,11
3. Alternierende Achtstufigkeit
4. Diatonik
5. Ganzton
6. Konstrukt - 0,1,4,5,8,9
*/



- "Architektur" von Vincent ansehen.

  Was er macht, ist mittels der Constraints testen, ob die Testliste im Dissonanzgrad-Bereich liegt. 

  - Was ist Environment?

  -> Dann nehme ich mir einfach mal ein Beispiel: 

  Liste [1,5,8] soll getestet werden, ob es Diss1 hat (dann ob es Diss0 hat).

  Ich hab eine Liste und die Constraints. Wie komme ich jetzt zu der Info, ob die Liste im Dissgrad liegt oder nicht?

  

- Wie kombiniert man Events? Mit merge().

- UnderlyingScale ist interessant

- Ein Dictionary bauen, wo die Parameter zusammen den Key bilden. Der Wert ist jeweils eine Liste mit Listen von Tönen. 

- Git Repository forken